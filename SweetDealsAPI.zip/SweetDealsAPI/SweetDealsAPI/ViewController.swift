//
//  ViewController.swift
//  SweetDealsAPI
//
//  Created by Anant Agrawal on 11/4/19.
//  Copyright © 2019 Anant Agrawal. All rights reserved.
//

import UIKit
import MapKit

class DealsTableViewController: UITableViewController {
  
  @IBOutlet weak var searchBar: UISearchBar!
  
  let dealRequest = DealRequest()
  
  var fullListOfDeals = [Deal]()
  
  var listOfDeals = [Deal]() {
    didSet {
      DispatchQueue.main.async {
        self.tableView.reloadData()
        self.navigationItem.title = "\(self.listOfDeals.count) Deals Found"
      }
    }
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
    searchBar.showsCancelButton = true
    searchBar.delegate = self as? UISearchBarDelegate
    
    
    dealRequest.getDeals(){
      (result: Result?) in
      if let result = result{
        print("printing the result now")
        print(result.deals[0].shortAnnouncementTitle)
        DispatchQueue.main.async{
          
          self.listOfDeals = result.deals
          self.fullListOfDeals = result.deals
        }
        
      } else {
        print("no result returned")
      }
    }
  }
  
  override func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return self.listOfDeals.count
  }
  
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
    
    let deal = listOfDeals[indexPath.row]
    
    cell.textLabel?.text = deal.shortAnnouncementTitle
    cell.detailTextLabel?.text = deal.merchant.name
    
    return cell
  }


}

extension DealsTableViewController: UISearchBarDelegate {
  
  func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
    
    guard let searchBarText = searchBar.text else {return}
        
    if searchBarText == "" {
      self.listOfDeals = self.fullListOfDeals
    } else {
      
      var resultListOfDeals = [Deal]()
      
      for deal in self.fullListOfDeals {
        if(deal.merchant.name.contains(searchBarText)){
          resultListOfDeals.append(deal)
        }
      }
      print(resultListOfDeals)
      self.listOfDeals = resultListOfDeals
      
    }
    
  }
  
  func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
    print("hello")
    self.searchBar.text = ""
    self.listOfDeals = self.fullListOfDeals
  }
  
  func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
    self.listOfDeals = self.fullListOfDeals
  }
}

